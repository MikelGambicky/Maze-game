using UnityEngine;
using UnityEngine.SceneManagement;

public class ExitPoint : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("You escaped the maze!");
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}