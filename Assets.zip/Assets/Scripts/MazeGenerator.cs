using UnityEngine;
using System.Collections.Generic;

public class MazeGenerator : MonoBehaviour
{
    [Header("Maze Settings")]
    public int width = 30;
    public int height = 30;
    public float cellSize = 10f;

    [Header("Prefabs")]
    public GameObject wallPrefab;
    public GameObject floorPrefab;
    public GameObject exitPrefab;

    private bool[,] visited;
    private bool[,] horizontalWalls;
    private bool[,] verticalWalls;

    void Start()
    {
        GenerateMaze();
    }

    void GenerateMaze()
    {
        visited = new bool[width, height];
        horizontalWalls = new bool[width, height + 1];
        verticalWalls = new bool[width + 1, height];

        for (int x = 0; x <= width; x++)
            for (int y = 0; y <= height; y++)
            {
                if (x < width) horizontalWalls[x, y] = true;
                if (y < height) verticalWalls[x, y] = true;
            }

        Stack<Vector2Int> stack = new Stack<Vector2Int>();
        Vector2Int start = new Vector2Int(0, 0);
        visited[start.x, start.y] = true;
        stack.Push(start);

        while (stack.Count > 0)
        {
            Vector2Int current = stack.Peek();
            List<Vector2Int> neighbors = GetUnvisitedNeighbors(current);

            if (neighbors.Count > 0)
            {
                Vector2Int chosen = neighbors[Random.Range(0, neighbors.Count)];
                RemoveWall(current, chosen);
                visited[chosen.x, chosen.y] = true;
                stack.Push(chosen);
            }
            else
            {
                stack.Pop();
            }
        }

        BuildMaze();
        PlaceExit();
        SpawnPlayer();
    }

    List<Vector2Int> GetUnvisitedNeighbors(Vector2Int cell)
    {
        List<Vector2Int> neighbors = new List<Vector2Int>();
        Vector2Int[] directions = {
            new Vector2Int(0, 1),
            new Vector2Int(0, -1),
            new Vector2Int(1, 0),
            new Vector2Int(-1, 0)
        };

        foreach (Vector2Int dir in directions)
        {
            Vector2Int neighbor = cell + dir;
            if (neighbor.x >= 0 && neighbor.x < width &&
                neighbor.y >= 0 && neighbor.y < height &&
                !visited[neighbor.x, neighbor.y])
            {
                neighbors.Add(neighbor);
            }
        }
        return neighbors;
    }

    void RemoveWall(Vector2Int a, Vector2Int b)
    {
        Vector2Int diff = b - a;
        if (diff.y == 1) horizontalWalls[a.x, a.y + 1] = false;
        else if (diff.y == -1) horizontalWalls[a.x, a.y] = false;
        else if (diff.x == 1) verticalWalls[a.x + 1, a.y] = false;
        else if (diff.x == -1) verticalWalls[a.x, a.y] = false;
    }

    void BuildMaze()
    {
        GameObject mazeParent = new GameObject("Maze");

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                Vector3 cellPos = new Vector3(x * cellSize, 0, y * cellSize);

                // Floor
                if (floorPrefab != null)
                {
                    GameObject floor = Instantiate(floorPrefab,
                        cellPos + new Vector3(cellSize / 2, 0, cellSize / 2),
                        Quaternion.identity, mazeParent.transform);
                    floor.transform.localScale = new Vector3(cellSize, 0.1f, cellSize);
                }

                // Bottom horizontal wall
                if (horizontalWalls[x, y])
                {
                    GameObject wall = Instantiate(wallPrefab,
                        cellPos + new Vector3(cellSize / 2, 4f, 0),
                        Quaternion.identity, mazeParent.transform);
                    wall.transform.localScale = new Vector3(cellSize, 8f, 1f);
                }

                // Left vertical wall
                if (verticalWalls[x, y])
                {
                    GameObject wall = Instantiate(wallPrefab,
                        cellPos + new Vector3(0, 4f, cellSize / 2),
                        Quaternion.Euler(0, 90, 0), mazeParent.transform);
                    wall.transform.localScale = new Vector3(cellSize, 8f, 1f);
                }
            }
        }

        // Right border
        for (int y = 0; y < height; y++)
        {
            Vector3 pos = new Vector3(width * cellSize, 4f, y * cellSize + cellSize / 2);
            GameObject wall = Instantiate(wallPrefab, pos,
                Quaternion.Euler(0, 90, 0), mazeParent.transform);
            wall.transform.localScale = new Vector3(cellSize, 8f, 1f);
        }

        // Top border
        for (int x = 0; x < width; x++)
        {
            Vector3 pos = new Vector3(x * cellSize + cellSize / 2, 4f, height * cellSize);
            GameObject wall = Instantiate(wallPrefab, pos,
                Quaternion.identity, mazeParent.transform);
            wall.transform.localScale = new Vector3(cellSize, 8f, 1f);
        }
    }

void PlaceExit()
{
    if (exitPrefab != null)
    {
        // Always spawn exit in the far corner quadrant
        int randomX = Random.Range(width * 3 / 4, width);
        int randomY = Random.Range(height * 3 / 4, height);

        Vector3 exitPos = new Vector3(
            randomX * cellSize + cellSize / 2,
            1f,
            randomY * cellSize + cellSize / 2
        );
        Instantiate(exitPrefab, exitPos, Quaternion.identity);
    }
}

void SpawnPlayer()
    {
        GameObject player = GameObject.FindWithTag("Player");
        if (player != null)
        {
            int randomX = Random.Range(0, width / 4);
            int randomY = Random.Range(0, height / 4);

            player.transform.position = new Vector3(
                randomX * cellSize + cellSize / 2,
                2f,
                randomY * cellSize + cellSize / 2
            );
        }
    }
}  